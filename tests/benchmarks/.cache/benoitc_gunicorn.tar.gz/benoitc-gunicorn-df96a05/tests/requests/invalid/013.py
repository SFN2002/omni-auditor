#
# This file is part of gunicorn released under the MIT license.
# See the NOTICE for more information.

from gunicorn.config import Config
from gunicorn.http.errors import LimitRequestHeaders

request = LimitRequestHeaders
cfg = Config()
cfg.set('limit_request_field_size', 14)

# once this option is removed, this test should not be dropped;
#  rather, add something involving unnessessary padding
cfg.set('permit_obsolete_folding', True)
